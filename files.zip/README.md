# FlytBase Inbound BDR Agent

Takes one raw inbound email (SQM / Atacama lithium lead) and runs six stages automatically:
qualification (MEDDIC), live-web account research, case-study matching on flytbase.com,
partner/GTM recommendation, adaptive email sequence, and AE handoff.

## Run
    pip install -r requirements.txt
    export ANTHROPIC_API_KEY=your-key      # never commit your key
    python agent.py                        # writes sqm_run_output.md
    python agent.py --dry-run              # tests plumbing with no API calls

## Design
- `ask()` wraps every model call; research stages enable the web search tool.
- Stages 4 and 5 are restricted to flytbase.com, so matches are found, not hard-coded.
- Step 0 extracts the referrer, industry and region from the email to drive the searches.
- Each stage's output feeds later stages. Retrieved URLs are logged in the report as evidence.

## Limitations
- Drafts emails but does not send them. No human review step. Web search can miss exact org-chart details.
