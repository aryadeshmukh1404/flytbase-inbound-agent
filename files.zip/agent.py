"""
FlytBase inbound BDR agent.
Input: one raw email. Output: a 6-stage markdown report (sqm_run_output.md).

Run:  pip install anthropic
      export ANTHROPIC_API_KEY=sk-ant-...      (Windows: set ANTHROPIC_API_KEY=...)
      python agent.py            # real run
      python agent.py --dry-run  # fake LLM, tests the plumbing only
"""
import json, os, sys, time

DRY = "--dry-run" in sys.argv
MODEL = os.environ.get("MODEL", "claude-sonnet-5-5")

EMAIL = """From: Rodrigo Castillo (r.castillo@sqm.cl)
Title: Head of Operations, Northern Operations Division
Company: Sociedad Quimica y Minera de Chile (SQM), Chile
Subject: Autonomous inspection for our Atacama lithium sites
Context: Looking for drone-based inspection for 3 large-scale, 24/7 lithium extraction sites in the Atacama Desert. Contracted crews are expensive and hazardous. Referred by Anglo American. Internal budget conversation scheduled for Q3."""

RULES = ("Be concise and specific. Never invent facts, numbers, names or URLs. "
         "If something is unknown, write UNKNOWN. Cite a source URL after every external fact.")

if not DRY:
    import anthropic
    client = anthropic.Anthropic()          # reads ANTHROPIC_API_KEY

SOURCES = {}   # stage name -> list of (title, url) the search tool really returned


def ask(stage, prompt, search=False, domains=None, max_tokens=4000):
    """One LLM call. If search=True the model may browse the live web."""
    if DRY:
        return f"[dry-run output for {stage}]"
    kwargs = {}
    if search:
        tool = {"type": "web_search_20250305", "name": "web_search", "max_uses": 8}
        if domains:
            tool["allowed_domains"] = domains      # restrict to e.g. flytbase.com
        kwargs["tools"] = [tool]
    messages = [{"role": "user", "content": prompt}]
    text, found = "", []
    for _ in range(5):                              # continue if the search loop pauses
        r = client.messages.create(model=MODEL, max_tokens=max_tokens,
                                   messages=messages, **kwargs)
        for b in r.content:
            if b.type == "text":
                text += b.text
            elif b.type == "web_search_tool_result" and isinstance(b.content, list):
                found += [(x.title, x.url) for x in b.content]
        if r.stop_reason != "pause_turn":
            break
        messages = [{"role": "user", "content": prompt}, {"role": "assistant", "content": r.content}]
    SOURCES[stage] = list(dict.fromkeys(found))
    return text.strip()


def run():
    log = lambda m: print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)
    out = {}

    # Step 0: extract entities so nothing (e.g. the referrer) is hard-coded
    log("Step 0: extracting entities from email")
    raw = ask("entities", "Return ONLY JSON with keys company, contact_title, industry, region, "
              "use_case, referrer, num_sites, timeline (UNKNOWN if absent).\n\nEMAIL:\n" + EMAIL,
              max_tokens=500)
    try:
        ent = json.loads(raw.replace("```json", "").replace("```", ""))
    except Exception:
        ent = {"company": "SQM", "referrer": "UNKNOWN", "industry": "UNKNOWN"}
    log(f"entities: {ent}")

    log("Stage 1: qualification (MEDDIC)")
    out[1] = ask("s1", "You are a senior inbound BDR at FlytBase (Physical AI / drone autonomy for large "
        "industrial sites). Apply MEDDIC (chosen because this is a multi-stakeholder, budget-gated "
        "industrial deal; BANT is too thin). Score Metrics, Economic Buyer, Decision Criteria, Decision "
        "Process, Identify Pain, Champion 0-2 each (total /12) with one-line reasoning. Sections: "
        "1 Framework and why; 2 Known info from email; 3 Missing info, each with a discovery question; "
        "4 Score table; 5 Fit and Priority (P1/P2/P3) with reasoning; 6 Risks. Use only facts in the "
        f"email. {RULES}\n\nEMAIL:\n{EMAIL}")

    log("Stage 2: live web research on the company")
    out[2] = ask("s2", f"Research {ent.get('company')} using web search and write a brief for a FlytBase AE. "
        "Sections: A) org structure and reporting lines relevant to the Northern Operations / Atacama lead; "
        "B) budget signals from public filings (capex, opex, technology investment); C) recent news and "
        "strategic announcements; D) shareholder/CEO letters revealing operational priorities; "
        "E) recommended FlytBase positioning. Prefer primary sources (company site, 20-F, investor "
        "presentations). If a section cannot be supported by a source, write NOT FOUND instead of "
        f"guessing. End with 'Gaps to verify'. {RULES}\n\nLEAD:\n{EMAIL}", search=True, max_tokens=6000)

    log("Stage 4: case-study matching on flytbase.com")
    out[4] = ask("s4", f"Search flytbase.com for case studies. The lead was referred by "
        f"'{ent.get('referrer')}', industry '{ent.get('industry')}', use case '{ent.get('use_case')}'. "
        "Find any case study involving the referrer, then rank the top 3 by fit (industry, use case, "
        "remote/harsh 24/7 ops, safety and cost) with URLs, and explain why #1 is strongest. If no "
        f"referrer case study exists, say so. {RULES}", search=True, domains=["flytbase.com"])

    log("Stage 5: partner / go-to-market motion")
    out[5] = ask("s5", "Search flytbase.com for its partner ecosystem (resellers, integrators, regional "
        f"partners, LATAM). Recommend direct AE vs partner-led for {ent.get('region')} given: 3 remote "
        "24/7 mining sites, enterprise deal complexity. If partner-led name the partner TYPE, any "
        f"specific partner the site actually lists, and rationale. State confidence. {RULES}\n\n"
        f"LEAD:\n{EMAIL}", search=True, domains=["flytbase.com"], max_tokens=3000)

    log("Stage 3: adaptive email sequence")
    out[3] = ask("s3", "Write a 4-email sequence from a FlytBase BDR to the lead. Senior operations head: "
        "concise, peer tone, no hype. Reference specific research findings and the referrer; each email "
        "targets 1-2 Stage 1 unknowns via a natural question and uses the matched case study. First give "
        "a progression table (email #, timing, goal, unknown targeted, branch if no reply / reply). Each "
        "email: subject, body under 120 words, CTA. Add a short Spanish version of Email 1. "
        f"{RULES}\n\nLEAD:\n{EMAIL}\n\nSTAGE1:\n{out[1]}\n\nRESEARCH:\n{out[2]}\n\n"
        f"CASE STUDY:\n{out[4]}\n\nGTM:\n{out[5]}", max_tokens=4500)

    log("Stage 6: AE handoff")
    out[6] = ask("s6", "Write an AE handoff under 500 words: 1 Buyer context (who, cares about, others "
        "involved); 2 Qualification status (MEDDIC score, knowns, unknowns); 3 Top 3 research highlights "
        "with URLs; 4 Recommended case study and why; 5 GTM motion; 6 Suggested next step with rationale, "
        f"owner, date. {RULES}\n\nLEAD:\n{EMAIL}\n\nS1:\n{out[1]}\n\nS2:\n{out[2]}\n\nS3:\n{out[3]}\n\n"
        f"S4:\n{out[4]}\n\nS5:\n{out[5]}", max_tokens=3000)

    titles = {1: "Qualification", 2: "Research Brief", 3: "Email Sequence",
              4: "Case Study Match", 5: "Partner / GTM", 6: "AE Handoff"}
    names = {1: "s1", 2: "s2", 3: "s3", 4: "s4", 5: "s5", 6: "s6"}
    md = [f"# Inbound Lead Run Output\n_Model: {MODEL} | Run: {time.ctime()}_\n"]
    for i in range(1, 7):
        md.append(f"\n## Stage {i}: {titles[i]}\n{out[i]}\n")
        src = SOURCES.get(names[i])
        if src:
            md.append("\n**Pages the search tool actually retrieved:**\n" +
                      "\n".join(f"- {t} - {u}" for t, u in src) + "\n")
    open("sqm_run_output.md", "w", encoding="utf-8").write("".join(md))
    log("Done -> sqm_run_output.md")


if __name__ == "__main__":
    run()
